import './baithi.css';
function Aboutus(){
  return (
      <div>
          <h3>Aboutus</h3>
      <div className="h8">
        <div className="b">
          <img className="b1" src="https://www.bing.com/images/search?view=detailV2&ccid=0tbVm2Og&id=3BAB135C0E447FF0A4394D35896576687AE5B771&thid=OIP.0tbVm2OgbRplpUFqLkm2ewHaHa&mediaurl=https%3a%2f%2fphunuvietnam.mediacdn.vn%2f179072216278405120%2f2020%2f5%2f18%2fho-chi-minh-2-15897692841381437643253.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.d2d6d59b63a06d1a65a5416a2e49b67b%3frik%3dcbflemh2ZYk1TQ%26pid%3dImgRaw%26r%3d0&exph=1200&expw=1200&q=anh+chu+tich+ho+chi+minh&simid=608030179855635210&FORM=IRPRST&ck=AD83D649A4E8E438198EE1AE313A81A4&selectedIndex=2&ajaxhist=0&ajaxserp=0" alt="Chu Tich"></img>
          <p><b>Chu Tich </b>Ho Chi Minh</p>
          <p>The founder is also ...</p>
          </div>
        <div className="b">
          <img className="b1" src="https://www.bing.com/images/search?view=detailV2&ccid=ekh0p%2f7O&id=B5A60EFD6F1E97AD2A6C0AF800028C8974850140&thid=OIP.ekh0p_7OgqMFVDwK_HDZPQHaE7&mediaurl=https%3a%2f%2fmtg.1cdn.vn%2f2021%2f03%2f10%2ftong-bi-thu.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.7a4874a7fece82a305543c0afc70d93d%3frik%3dQAGFdImMAgD4Cg%26pid%3dImgRaw%26r%3d0&exph=434&expw=653&q=anh+tong+bi+thu&simid=608043807790751568&FORM=IRPRST&ck=F54957326747533FC06CC3EEDD02E250&selectedIndex=2&ajaxhist=0&ajaxserp=0" alt="Tong Bi THu"></img>
          <p><b>TOng Bi THu </b>Nguyen Phu Trong</p>
          <p>10 years of experience in building a specialized technical team</p>
        </div>
      </div>
      <div className="b">
          <img className="b1" src="https://www.bing.com/images/search?view=detailV2&ccid=JCfo69tA&id=29E350F701E8F991A4B978098794E5E315F9FC6D&thid=OIP.JCfo69tA6c3yFjuEzLA0kAHaE8&mediaurl=https%3a%2f%2fdoanhnhanplus.vn%2fwp-content%2fuploads%2f2020%2f03%2fdnp-CEO_EcoTruck.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.2427e8ebdb40e9cdf2163b84ccb03490%3frik%3dbfz5FePllIcJeA%26pid%3dImgRaw%26r%3d0&exph=567&expw=850&q=anh+CEO+&simid=608025605712776407&FORM=IRPRST&ck=13414A630B6B759FBED3FA70ACA10817&selectedIndex=1&ajaxhist=0&ajaxserp=0" alt="CEO"></img>
          <p><b>CEO: </b>LE HOANG ANH</p>
          <p>5 years of experience in .....</p>
          </div>
      </div>
    );
};

export default Aboutus;