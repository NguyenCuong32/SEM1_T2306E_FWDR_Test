import './baithi.css';
const Home = () => {
    return(
        <>
    <div><br/>
   <img className="h" src = {"http://ghttps://www.bing.com/images/search?view=detailV2&ccid=tpdxbYwV&id=E436B1BCAF790538EFF0E7F0025DBEBDD528FA82&thid=OIP.tpdxbYwVUMQZe8d9qIQfvgHaFj&mediaurl=https%3A%2F%2F2.bp.blogspot.com%2F-bQTld96S_qs%2FUkP79rKafVI%2FAAAAAAAAAhU%2Fc4dWVQ1b874%2Fs1600%2Fanh-dep-hinh-nen-thien-nhien-2.jpg&cdnurl=https%3A%2F%2Fth.bing.com%2Fth%2Fid%2FR.b697716d8c1550c4197bc77da8841fbe%3Frik%3Dgvoo1b2%252bXQLw5w%26pid%3DImgRaw%26r%3D0&exph=900&expw=1200&q=anh+dep&simid=608030416055595611&form=IRPRST&ck=1F87C6D19E35F0003BF2901B3EFE0F55&selectedindex=0&ajaxhist=0&ajaxserp=0&vt=0&sim=11enk.mediacdn.vn/k:2015/2-1440133142840/facebook-bat-dau-thu-nghiem-dang-anh-dong-tren-fanpage-va-quang-cao.gif"}/>
   </div>    
<br/><br/><br/>
        <div>
          <h1>ABC limited liability company</h1>
          <h2>Specializing in providing information technology solutions in the fields of AI, Finance...</h2>
          </div>
     
        </>
    )
};