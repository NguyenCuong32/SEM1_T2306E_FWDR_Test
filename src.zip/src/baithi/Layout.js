import { Outlet, Link } from "react-router-dom";
import './baithi.css';
const Layout = () => {
    return(
        <div>
           <header>
    <div class="h2">
    <Link className="h1" elememt="/Home">Home</Link>
    <Link className="h1" elememt="Aboutus">Aboutus</Link>
    <Link className="h1" elememt="/Register">Register</Link>
            <Outlet />
            </div>
            </header>
        </div>
    )
};

export default Layout;