import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import Home from './pages/home';
import About from './pages/about';
import Register from './pages/register';
import Layout from './pages/layout';
function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Layout />}>
        <Route path='home' element={<Home/>}></Route>
        <Route path='about' element={<About/>}></Route>
        <Route path='register' element={<Register/>}></Route>
      </Route>
    </Routes>
  </BrowserRouter>
  );
}

export default App;
