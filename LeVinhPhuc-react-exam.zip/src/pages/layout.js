import { Outlet, Link } from "react-router-dom"
import '../App.css';
const Layout = () => {
    return (
        <nav className="nav">
            <Link className="home" to="/home">Home</Link>
            <Link className="about" to="/about">About Us</Link>
            <Link className="register" to="/register">Register</Link>
            <Outlet/>
        </nav>
    )
}
export default Layout;