import '../App.css'
import logo1 from './ava1.jpg'
import logo2 from './ava2.jpg'
import logo3 from './ava3.png'
const About = () => {
    return (
       <div>
        <h2 className='about-header'><b>About us</b></h2>
        <div className='container'>
            <img className='avatar' src={logo1} alt='user-avatar'></img>
            <img className='avatar' src={logo2} alt='user-avatar'></img>
        </div>
        <div className='container'>
            <div><b>CEO: </b>Nguyen Thi Hanh</div>
            <div><b>CTO: </b>Nguyen Thanh Binh</div>
        </div>
        <div id='avatar-cfo'>
            <img className='avatar' src={logo3} alt='user-avatar'></img>
        </div>
        <div><b>CFO: </b>Nguyen Van Hoa</div>
        <div>5 years of experience in financial management</div>
       </div>
    );
}

export default About;