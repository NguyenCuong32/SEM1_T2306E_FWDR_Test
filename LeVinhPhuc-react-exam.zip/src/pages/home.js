import '../App.css'
import logo from './banner.jpg'
const Home = () => {
    return (
    <div>
        <img src={logo} alt='company-logo' className='banner'></img>
        <div><b>ABC limited liability company</b></div> 
        <div>specializing in providing information about car</div>
    </div>
    );
}

export default Home;