import '../App.css'
const Register = () => {
    return (
    <section className='container-all-register'>
        <div className='container-register'>
            <b>Product:</b>
            <input placeholder='Product'></input>
        </div>
        <div className='container-register'>
            <b>Name:</b>
            <input placeholder='Name'></input>
        </div>
        <div className='container-register'>
            <b>Phone number:</b>
            <input placeholder='Phone number'></input>
        </div>
        <div className='container-register'>
            <b>Email:</b>
            <input placeholder='email'></input>
        </div>
        <div className='button-container'>
            <button id='register'>Register</button>
            <button>Cancel</button>
        </div>
    </section>
    );
}

export default Register;